@echo off
title GSTR-2B to TallyPrime Import Tool — By Monil Shah
color 1F
cls

echo.
echo  ============================================================
echo   GSTR-2B to TallyPrime Import Tool
echo   By Monil Shah
echo  ============================================================
echo.

:: ── Check Python is installed ──────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    color 4F
    echo  [ERROR] Python is not installed or not in PATH.
    echo.
    echo  Please install Python from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

:: ── Check gstr2b_to_tally.py exists ───────────────────────────
if not exist "%~dp0gstr2b_to_tally.py" (
    color 4F
    echo  [ERROR] gstr2b_to_tally.py not found in this folder.
    echo.
    echo  Make sure START_TOOL.bat and gstr2b_to_tally.py
    echo  are in the same folder.
    echo.
    pause
    exit /b 1
)

:: ── Install dependencies if needed ────────────────────────────
echo  Checking dependencies...
pip show fastapi >nul 2>&1
if errorlevel 1 (
    echo  Installing required libraries. This may take a minute...
    echo.
    pip install fastapi uvicorn requests python-multipart openpyxl pandas
    echo.
    echo  Libraries installed successfully.
    echo.
)

:: ── Start the Python server in background ─────────────────────
echo  Starting server...
start "" /B python "%~dp0gstr2b_to_tally.py"

:: ── Wait for server to be ready ───────────────────────────────
echo  Waiting for server to start...
timeout /t 3 /nobreak >nul

:: ── Try up to 10 seconds for server to respond ────────────────
set /a tries=0
:waitloop
curl -s http://localhost:8000/ >nul 2>&1
if not errorlevel 1 goto server_ready
set /a tries+=1
if %tries% geq 10 goto server_timeout
timeout /t 1 /nobreak >nul
goto waitloop

:server_timeout
echo.
echo  [WARNING] Server is taking longer than expected.
echo  Opening browser anyway. If the page does not load,
echo  wait a few seconds and refresh.
echo.
goto open_browser

:server_ready
echo  Server is running.
echo.

:open_browser
:: ── Open the UI in default browser ────────────────────────────
echo  Opening browser...
start "" "http://localhost:8000/ui"

echo.
echo  ============================================================
echo   Tool is running at: http://localhost:8000/ui
echo.
echo   DO NOT CLOSE THIS WINDOW while using the tool.
echo   To stop the tool, close this window.
echo  ============================================================
echo.

:: ── Keep window open so server keeps running ──────────────────
pause